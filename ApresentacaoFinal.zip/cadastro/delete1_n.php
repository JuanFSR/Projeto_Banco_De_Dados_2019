
<?php
  session_start();

$host = "localhost";
$user = "root";
$pass = "";
$banco = "cadastro_pessoa";
$conexao = mysqli_connect($host, $user, $pass, $banco) or die (mysqli_error($conexao));
mysqli_select_db($conexao,$banco) or die (mysqli_error($conexao));

$id_an =$_POST['numero'];

$ani_resu = mysqli_query($conexao, "SELECT * FROM cadastro_animal WHERE id_animal='$id_an'") or die(mysqli_error("Erro"));

	$row = mysqli_fetch_array($ani_resu);
		$id_ani = $row['id_animal'];

if($row > 0){
	

			
		$email_atual = $_SESSION['email'];

		//Aqui no di_atual não está pegando o id
		$id_at = mysqli_query($conexao, "SELECT * FROM usuarios WHERE email='$email_atual'") or die(mysqli_error($conexao));
		$ii = mysqli_fetch_array($id_at);

		if($ii['id'] == $row['id_usuario']){
		$up = mysqli_query($conexao, "DELETE FROM cadastro_animal WHERE id_animal=$id_ani");

		echo $ii_animal['id_animal'];
		echo $ii['id'];
		echo $id_an;

		header('Location: meus_cachorros.php');
		echo "<script>alert('Exclusão concluida com sucesso !');</script>";	
		}
		else{
			
			echo "<center>Você não cadastrou esse animal !</center>";
			header('Location: delete_pag_N.php');
		}
	}
	else{
		echo "ERRO!";
		header('Location: delete_pag_N.php');
	}
	





?>
