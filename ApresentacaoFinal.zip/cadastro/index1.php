<?php
$host = "localhost";
$user = "root";
$pass = "";
$banco = "cadastro_pessoa";
$conexao = mysqli_connect($host, $user, $pass, $banco) or die (mysqli_error());
mysqli_select_db($conexao,$banco) or die (mysqli_error());

$result_animais = "SELECT * FROM cadastro_animal";
$resultado_animais = mysqli_query($conexao, $result_animais );
//$row_ani = mysqli_fetch_assoc($resultado_animais);
/*  session_start();
  if(!isset($_SESSION["email"]) || !isset($_SESSION["senha"])){
    header("Location: login.php");
    exit;
  }else{
    echo "<center>Voce está logado!</center>";
  }*/

?>
<html lang="en">
  <head>
    <meta charset="utf-8">
    <meta name="Comprarport" content="width=device-width, initial-scale=1, shrink-to-fit=no">
    <meta name="description" content="">
    <meta name="author" content="">
    <link rel="icon" href="Imagens/papagaio.png">

    <title>Início</title>

    <!-- Bootstrap core CSS -->
    <link href="bootstrap.min.css" rel="stylesheet">

    <!-- Custom styles for this template -->
    <link href="style.css" rel="stylesheet">
  </head>

  <body>

    <header>
    	<a href="index1.php"><img id="logo" src="Imagens/papagaio.png"></a>
    	<input type="busca" name="busca" placeholder=" Buscar"></input>
    	<a href="#busca"><img id="lupa" src="Imagens/lupa.png"></a>
    	<button onclick="window.location.href='logout.php'" id="ent" type="button" name="login">Logout</button>
      
    	<a href="perfil.html"><img id="menu" src="Imagens/tt.png"></a>
    </header>

    <main role="main">
<table id="encad">
      <div id="categorias">
      	<ul>
      		<li><a href="#cat1">Recém Adotados</a></li>
      		<li><a href="#cat2">Adote um animalzinho</a></li>
      		<li><a href="Anuncio_Animal.html">Anuncie</a></li>
          <li><a href="meus_cachorros.php">Meus cadastros</a></li>
      		<li><a href="#cat5">Contato</a></li>
      	</ul>
      </div>

      <div class="album py-5 bg-light">
        <div class="container">
      <div class="row">
          <?php while($row_ani = mysqli_fetch_assoc($resultado_animais)){ ?> 

  <div class="col-sm-6 col-md-4">
    <div class="thumbnail">
      <img src="imagem/dog.jpg" alt="...">
      <div class="caption text-center">
        <h3><?php echo $row_ani['raca']; ?></h3>  
        <p>...</p>
        <p><a href="#" class="btn btn-primary" role="button">Informações</a> </p>
      </div>
    </div>
  </div>
  <?php } ?>
</div>
       </div>    
    </main>


    <footer class="text-muted">
      <div class="container">
      	<p class="float-right">Juan Felipe da Silva Rangel, 2046385.
        <br>Vinicíus Henrique Soares, 2046458.</p>
        <p>
          <a href="#">Back to top</a>
        </p>
        <p>&copy; Papagaio Adoções, ajude um amiguinho que gosta de ABACATE!</p>
      </div>
    </footer>

  </body>
</html>
