<?php
  session_start();

$host = "localhost";
$user = "root";
$pass = "";
$banco = "cadastro_pessoa";
$conexao = mysqli_connect($host, $user, $pass, $banco) or die (mysqli_error($conexao));
mysqli_select_db($conexao,$banco) or die (mysqli_error($conexao));

$email_atual = $_SESSION['email'];

//Aqui no di_atual não está pegando o id
$id_at = mysqli_query($conexao, "SELECT * FROM usuarios WHERE email='$email_atual'") or die(mysqli_error($conexao));

$ii = mysqli_fetch_array($id_at);

$cad_atual = mysqli_query( $conexao,  "SELECT * FROM cadastro_animal WHERE id_usuario='$ii[id]' ") or die(mysqli_error($conexao));

if($cad_atual === FALSE) { 
   die(mysqli_error());
}



//Teste de variaveis
 // echo $ii['id'];

 // echo $aa['id_animal'];


?>

<html lang="en">
  <head>
    <meta charset="utf-8">
    <meta name="Comprarport" content="width=device-width, initial-scale=1, shrink-to-fit=no">
    <meta name="description" content="">
    <meta name="author" content="">
    <link rel="icon" href="Imagens/papagaio.png">

    <title>Início</title>

    <link href="bootstrap.min.css" rel="stylesheet">

  
    <link href="style.css" rel="stylesheet">
  </head>

  <body>

    <header>
      <a href="index1.php"><img id="logo" src="Imagens/papagaio.png"></a>
      <input type="busca" name="busca" placeholder=" Buscar"></input>
      <a href="#busca"><img id="lupa" src="Imagens/lupa.png"></a>
      <button onclick="window.location.href='log.php'" id="ent" type="button" name="login">Login</button>
      <button onclick="window.location.href='.php'" id="ent" type="button" name="login">Cadastrar</button>
      
      <a href="perfil.html"><img id="menu" src="Imagens/tt.png"></a>
    </header>

    <main role="main">
<table id="encad">
      <div id="categorias">
        <ul>
          <li><a href="#cat1">Recém Adotados</a></li>
          <li><a href="#cat2">Adote um animalzinho</a></li>
          <li><a href="Anuncio_Animal.html">Anuncie</a></li>
          <li><a href="meus_cachorros.php">Meus cadastros</a></li>
          <li><a href="#cat5">Contato</a></li>
        </ul>
      </div>

      <div class="album py-5 bg-light">
        <div class="container">
      <div class="row">
          <?php while($row_ani = mysqli_fetch_assoc($cad_atual)){ ?> 

  <div class="col-sm-6 col-md-4">
    <div class="thumbnail">
      <img src="imagem/dog.jpg" alt="...">
      <div class="caption text-center">
        <h3><?php echo $row_ani['raca']; ?></h3>  
        <p>Número de identificação: <?php  echo $row_ani['id_animal'] ?></p>
        <p><a href="#" class="btn btn-primary" role="button">Editar</a> 
        <a href="delete_pag_N.php" class="btn btn-primary" role="button">Excluir</a> </p>
      </div>
    </div>
  </div>
  <?php } ?>
</div>
       </div>    
    </main>


    <footer class="text-muted">
      <div class="container">
        <p class="float-right">Juan Felipe da Silva Rangel, 2046385.
        <br>Vinicíus Henrique Soares, 2046458.</p>
        <p>
          <a href="#">Back to top</a>
        </p>
        <p>&copy; Papagaio Adoções, ajude um amiguinho que gosta de ABACATE!</p>
      </div>
    </footer>

  </body>
</html>
