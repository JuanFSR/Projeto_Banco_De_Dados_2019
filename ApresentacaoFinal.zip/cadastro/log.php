  <!doctype html>
<html lang="en">
  <head>
    <meta charset="utf-8">
    <meta name="Comprarport" content="width=device-width, initial-scale=1, shrink-to-fit=no">
    <meta name="description" content="">
    <meta name="author" content="">
    <link rel="icon" href="Imagens/papagaio.png">

    <title>Entrar</title>

    <!-- Bootstrap core CSS -->
    <link href="bootstrap.min.css" rel="stylesheet">

    <!-- Custom styles for this template -->
    <link href="style.css" rel="stylesheet">
    <link href="stylel.css" rel="stylesheet">
  </head>

  <body>

    <header>
    	<a href="index1.php"><img id="logo" src="Imagens/papagaio.png"></a>
    	<input type="busca" name="busca" placeholder=" Buscar"></input>
    	<a href="#busca"><img id="lupa" src="Imagens/lupa.png"></a>
    	<a href="perfil.html"><img id="menu" src="Imagens/tt.png"></a>
    </header>

    <main role="main">
      <div class="album py-5 bg-light">
      <div class="container">


        <div id="log">
        	<div id="tit"><p align="center">Login</p></div>


          <!-- Area do login -->
          <div id="login" >
            <table id="encad">
              <tr>
                <td id="divs">
                  <form method="post" action="autentica.php">
                    <table id="encad_table">
                     <tr>
                      <td>Email:</td>
                      <td>
                        <input type="text" name="email" id="email" class="campo" maxlength="40" placeholder="Email" >
                      </td>
                      </tr>
                      <tr>
                       <td>Senha:</td>
                       <td>
                         <input type="password" name="senha" id="senha" class="campo" maxlength="22" placeholder="Senha" >
                        </td>
                      </tr>
                      <tr id="btns"></tr>
                      <tr>
                        <td colspan="2">
                          <input type="submit" name="Entrar"  id="btn_ent" class="area_btn"/>
                        </form>
                          <!-- Botão 1 -->

                         <!--button type="button" onclick="login(usuario.value, senha.value)" id="btn_ent" class="area_btn">
                            <div class="efeito_btn"></div><div class="efeito_txt" id="text_ent">Entrar</div>
                         </button-->
                          <!-- Botao 2 
                         <button type="button" id="btn_eas" Onclick="eas()"  class="area_btn">
                            <div class="efeito_btn"></div><div class="efeito_txt" id="text_eas">Esqueceu a Senha?</div>
                        </button-->
                        <form action="configurar.php">
                          <input type="submit" name="Esqueci minha senha" value="Esqueci minha senha" id="btn" class="area_btn"/>
                          </form>
                        </td>
                      </tr>
                    </table>
                  </form>
                </td>
              </tr>
           </table>
          </div>
<!-- Fim do Login -->
        </div>
      </div>
    </div>
    </div>

    </main>

    <footer class="text-muted">
      <div class="container">
      	<p class="float-right">Juan Felipe da Silva Rangel, 2046385.
        <br>Vinicíus Henrique Soares, 2046458.</p>
        <p>
          <a href="#">Back to top</a>
        </p>
        <p>&copy; Papagaio Adoções, ajude um amiguinho que gosta de ABACATE!</p>
      </div>
    </footer>

  </body>
</html>
