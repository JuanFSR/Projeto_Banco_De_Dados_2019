<html>
<head>
	<title>Cadastrando</title>
	<script type="text/javascript">
	function loginsuccessfully(){
		setTimeout("window.location='index1.php'", 2000);
	}
	function loginfailed(){
		setTimeout("window.location='log.php'", 2000);	
	}
	</script>
</head>
<body>
<?php
$host = "localhost";
$user = "root";
$pass = "";
$banco = "cadastro_pessoa";
$conexao = mysqli_connect($host, $user, $pass, $banco) or die (mysqli_error());
mysqli_select_db($conexao,$banco) or die (mysqli_error());

$raca = $_POST['raca'];
$email = $_POST['email'];
$telefone = $_POST['telefone'];
$result = mysqli_query($conexao, "SELECT id FROM usuarios WHERE email='$email'") or die(mysqli_error());

$row = mysqli_fetch_array($result);
$id_usuario = $row['id'];


$sql = mysqli_query($conexao,"INSERT INTO cadastro_animal(raca,telefone,id_usuario) VALUES ('$raca',$telefone,$id_usuario) ");
echo "$raca";
echo "$id_usuario";
echo "$telefone";

echo "<center>Cadastro efetuado com sucesso!</center>";
echo "<script>loginsuccessfully()</script>";

?>
</body>
</html>