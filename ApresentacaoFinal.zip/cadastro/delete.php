<!DOCTYPE html>
<html>
<head>
	<title>Deletando</title>
	<script type="text/javascript">
	function loginsuccessfully(){
		setTimeout("window.location='log.php'", 200000);
	}
	function loginfailed(){
		setTimeout("window.location='delete.php'", 200000);	
	}
	</script>
</head>
<body>

<?php
$host = "localhost";
$user = "root";
$pass = "";
$banco = "cadastro_pessoa";
$conexao = mysqli_connect($host, $user, $pass, $banco) or die (mysqli_error());
mysqli_select_db($conexao,$banco) or die (mysqli_error());


	$email = $_POST['email'];
	$senha = $_POST['senha'];
	$result = mysqli_query($conexao, "SELECT id FROM usuarios WHERE email='$email' and senha='$senha' ") or die(mysqli_error());

	$row = mysqli_fetch_array($result);
		$id = $row['id'];
	if($row > 0){
	$up = mysqli_query($conexao, "DELETE FROM usuarios WHERE id=$id");
	//fazer verificação
	echo "Sua conta foi deletada com sucesso";
	header('Location: log.php');
	
	}
	else{
		//Está funcionando, só não manda a mensagem
		header('Location: pag_delete.php');
		echo "Por favor tente novamente";
	}
?>


</body>
</html>
