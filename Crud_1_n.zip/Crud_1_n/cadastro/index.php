<?php
$host = "localhost";
$user = "root";
$pass = "";
$banco = "cadastro_pessoa";
$conexao = mysqli_connect($host, $user, $pass, $banco) or die (mysqli_error());
mysqli_select_db($conexao,$banco) or die (mysqli_error());

/*  session_start();
  if(!isset($_SESSION["email"]) || !isset($_SESSION["senha"])){
    header("Location: login.php");
    exit;
  }else{
    echo "<center>Voce está logado!</center>";
  }*/

?>
<html lang="en">
  <head>
    <meta charset="utf-8">
    <meta name="Comprarport" content="width=device-width, initial-scale=1, shrink-to-fit=no">
    <meta name="description" content="">
    <meta name="author" content="">
    <link rel="icon" href="Imagens/papagaio.png">

    <title>Início</title>

    <!-- Bootstrap core CSS -->
    <link href="bootstrap.min.css" rel="stylesheet">

    <!-- Custom styles for this template -->
    <link href="style.css" rel="stylesheet">
  </head>

  <body>

    <header>
    	<a href="index.html"><img id="logo" src="Imagens/papagaio.png"></a>
    	<input type="busca" name="busca" placeholder=" Buscar"></input>
    	<a href="#busca"><img id="lupa" src="Imagens/lupa.png"></a>
    	<button onclick="window.location.href='login.php'" id="ent" type="button" name="login">Login</button>
      <button onclick="window.location.href='.php'" id="ent" type="button" name="login">Sopa</button>
      
    	<a href="perfil.html"><img id="menu" src="Imagens/tt.png"></a>
    </header>

    <main role="main">

      <div id="categorias">
      	<ul>
      		<li><a href="#cat1">Recém Adotados</a></li>
      		<li><a href="#cat2">Adote um animalzinho</a></li>
      		<li><a href="Anuncio_Animal.html">Anuncie</a></li>
          <li><a href="#cat4">Relatos</a></li>
      		<li><a href="#cat5">Contato</a></li>
      	</ul>
      </div>

      <div class="album py-5 bg-light">
        <div class="container">


        <div id="cat">
        	<div id="tit"><p>Categoria</p></div>
          <div class="row">
            <div class="col-md-4">
              <div class="card mb-4 shadow-sm">
                <img class="card-img-top" src="Imagens/imagem.jpeg" alt="Card image cap">
                <div class="card-body">
                  <p class="card-text">Local reservado para a descrição das adoções recentes</p>
                  <div class="d-flex justify-content-between align-items-center">
                    
                  </div>
                </div>
              </div>
            </div>
            <div class="col-md-4">
              <div class="card mb-4 shadow-sm">
                <img class="card-img-top" src="Imagens/imagem.jpeg" alt="Card image cap">
                <div class="card-body">
                  <p class="card-text">Local reservado para a descrição das adoções recentes</p>
                  <div class="d-flex justify-content-between align-items-center">
                    
                  </div>
                </div>
              </div>
            </div>
            <div class="col-md-4">
              <div class="card mb-4 shadow-sm">
                <img class="card-img-top" src="Imagens/imagem.jpeg" alt="Card image cap">
                <div class="card-body">
                  <p class="card-text">Local reservado para a descrição das adoções recentes</p>
                  <div class="d-flex justify-content-between align-items-center">
                    
                  </div>
                </div>
              </div>
            </div>

            <div class="col-md-4">
              <div class="card mb-4 shadow-sm">
                <img class="card-img-top" src="Imagens/imagem.jpeg" alt="Card image cap">
                <div class="card-body">
                  <p class="card-text">Local reservado para a descrição das adoções recentes</p>
                  <div class="d-flex justify-content-between align-items-center">
                    
                  </div>
                </div>
              </div>
            </div>
            <div class="col-md-4">
              <div class="card mb-4 shadow-sm">
                <img class="card-img-top" src="Imagens/imagem.jpeg" alt="Card image cap">
                <div class="card-body">
                  <p class="card-text">Local reservado para a descrição das adoções recentes</p>
                  <div class="d-flex justify-content-between align-items-center">
                    
                  </div>
                </div>
              </div>
            </div>
            <div class="col-md-4">
              <div class="card mb-4 shadow-sm">
                <img class="card-img-top" src="Imagens/imagem.jpeg" alt="Card image cap">
                <div class="card-body">
                  <p class="card-text">Local reservado para a descrição das adoções recentes</p>
                  <div class="d-flex justify-content-between align-items-center">
                    
                  </div>
                </div>
              </div>
            </div>

            <div class="col-md-4">
              <div class="card mb-4 shadow-sm">
                <img class="card-img-top" src="Imagens/imagem.jpeg" alt="Card image cap">
                <div class="card-body">
                  <p class="card-text">Local reservado para a descrição das adoções recentes</p>
                  <div class="d-flex justify-content-between align-items-center">
                    
                  </div>
                </div>
              </div>
            </div>      <div class="col-md-4">
              <div class="card mb-4 shadow-sm">
                <img class="card-img-top" src="Imagens/imagem.jpeg" alt="Card image cap">
                <div class="card-body">
                  <p class="card-text">Local reservado para a descrição das adoções recentes</p>
                  <div class="d-flex justify-content-between align-items-center">
                    
                  </div>
                </div>
              </div>
            </div>
            <div class="col-md-4">
              <div class="card mb-4 shadow-sm">
                <img class="card-img-top" src="Imagens/imagem.jpeg" alt="Card image cap">
                <div class="card-body">
                  <p class="card-text">Local reservado para a descrição das adoções recentes</p>
                  <div class="d-flex justify-content-between align-items-center">
                    
                  </div>
                </div>
              </div>
            </div>
          </div>
        </div>
      </div>
    </div>

    </main>

    <footer class="text-muted">
      <div class="container">
      	<p class="float-right">Juan Felipe da Silva Rangel, 2046385.
        <br>Vinicíus Henrique Soares, 2046458.</p>
        <p>
          <a href="#">Back to top</a>
        </p>
        <p>&copy; Papagaio Adoções, ajude um amiguinho que gosta de ABACATE!</p>
      </div>
    </footer>

  </body>
</html>
