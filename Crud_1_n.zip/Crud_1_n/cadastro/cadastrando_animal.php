<html>
<head>
	<title>Cadastrando</title>
	<script type="text/javascript">
	function loginsuccessfully(){
		setTimeout("window.location='index.php'", 2000);
	}
	function loginfailed(){
		setTimeout("window.location='login.php'", 2000);	
	}
	</script>
</head>
<body>
<?php
$host = "localhost";
$user = "root";
$pass = "";
$banco = "cadastro_pessoa";
$conexao = mysqli_connect($host, $user, $pass, $banco) or die (mysqli_error());
mysqli_select_db($conexao,$banco) or die (mysqli_error());

$raca = $_POST['raca'];
$email = $_POST['email'];
$telefone = $_POST['telefone'];
$result = mysqli_query($conexao, "SELECT id FROM usuarios WHERE email='$email'") or die(mysqli_error());

$row = mysqli_fetch_array($result);
$id_usuario = $row['id'];

echo "$raca";
echo "$id_usuario";

$sql = mysqli_query($conexao,"INSERT INTO cadastro_animal(raca,telefone,email,id_usuario) VALUES ('$raca','$telefone','$email','$id_usuario') ");

echo "<center>Cadastro efetuado com sucesso!</center>";
echo "<script>loginsuccessfully()</script>";

?>
</body>
</html>