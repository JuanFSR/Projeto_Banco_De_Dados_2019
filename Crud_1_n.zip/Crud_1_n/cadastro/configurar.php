<?php
  
?>

<html lang="en">
  <head>
    <meta charset="utf-8">
    <meta name="Comprarport" content="width=device-width, initial-scale=1, shrink-to-fit=no">
    <meta name="description" content="">
    <meta name="author" content="">
    <link rel="icon" href="Imagens/papagaio.png">

    <title>Entrar</title>

    <!-- Bootstrap core CSS -->
    <link href="bootstrap.min.css" rel="stylesheet">

    <!-- Custom styles for this template -->
    <link href="style.css" rel="stylesheet">
    <link href="stylel.css" rel="stylesheet">


<script>
  function alterar(senha, nova_senha, confir_nova_senha){
    if (nova_senha == "" || confir_nova_senha == "" || senha == "") {
    alert("Um ou mais campos estão em branco. Preencha-os para alterar sua senha.");
  } else{
    if (nova_senha == confir_nova_senha) {

      var xmlhttp = new XMLHttpRequest();
      xmlhttp.onreadystatechange = function() {
        if (this.readyState == 4 && this.status == 200) {
    
    if(this.responseText == "1")
    {
      alert("Senha alterada com sucesso.");
      window.location.reload();
    } else{
      if(this.responseText == "2")
      {
        alert("Senha atual errada. Tente novamente.");
        window.location.reload();
      } else{
        alert("Erro interno, Favor entrar em contato.");
      }
    }
            }
        };
    
    xmlhttp.open('GET', 'config.php?email=' + email + '&senha=' + senha + '&nova_senha=' + nova_senha , true);
        xmlhttp.send(); 
        
    } else {
      alert("Senhas novas não coincidem.");
  }
}
}
</script>

  </head>

  <body>

    <header>
      <a href="index.html"><img id="logo" src="Imagens/papagaio.png"></a>
      <input type="busca" name="busca" placeholder=" Buscar"></input>
      <a href="#busca"><img id="lupa" src="Imagens/lupa.png"></a>
      <button onclick="window.location.href='login.html'" id="ent" type="button" name="login">Entrar/Cadastrar</button>
      <a href="perfil.html"><img id="menu" src="Imagens/tt.png"></a>
    </header>

    <main role="main">
      <div class="album py-5 bg-light">
      <div class="container">



    <main role="main">
      <div id="categorias">
        <ul>
          <li><a href="chamado.php">Abrir Chamado</a></li>
          <li><a href="chamadoh.php">Historico</a></li>
          <li><a href="configurar.php">Alterar Dados</a></li>
        </ul>
      </div>
      <div class="album py-5 bg-light">
      <div class="container">

        <div id="cat">
        	<div id="tit"><p>Alterar Dados</p></div>

          <div id="alterar">
<h1>Alterar Senha</h1>
<p>Para alterar sua senha digite a senha atual, digite a senha nova, e reescreva a senha nova para confirmar e aperte em alterar.
</p>
<br>

<form method="post" action="config.php">
  Digite seu email: &nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp
<input type="text" name="email" id="email"  maxlength="50" placeholder="Email" >
<br>
<br>
  Digite sua senha atual: &nbsp&nbsp&nbsp&nbsp
<input type="password" name="senha" id="senhaa"  maxlength="50" placeholder="Senha atual" >
<br>
<br>
Digite a senha nova: &nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp
<input type="password" name="nova_senha" id="senhan"  maxlength="50" placeholder="Senha nova">
<br>
<br>
Repita a senha nova: &nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp
<input type="password" name="confir_nova_senha" id="senhac"  maxlength="50" placeholder="confirmar Senha nova">
<br>
<div id="res" style="font:14px arial; margin:0px 225px; visibility:hidden;">olá</div>
<br><br><br>
<input type='submit' id='btn' class='btn' value='Alterar'>
</form>


        </div>

        

      </div>
    </div>
    </div>
</div></div></main>
</div></div>
    </main>

  <footer class="text-muted">
      <div class="container">
        <p class="float-right">Juan Felipe da Silva Rangel, 2046385.
        <br>Vinicíus Henrique Soares, 2046458.</p>
        <p>
          <a href="#">Back to top</a>
        </p>
        <p>&copy; Papagaio Adoções, ajude um amiguinho que gosta de ABACATE!</p>
      </div>
    </footer>

  </body>
</html>
