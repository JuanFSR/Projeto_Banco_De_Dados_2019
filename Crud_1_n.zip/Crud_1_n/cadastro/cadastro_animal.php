<!doctype html>
<html lang="en">
  <head>
    <meta charset="utf-8">
    <meta name="Comprarport" content="width=device-width, initial-scale=1, shrink-to-fit=no">
    <meta name="description" content="">
    <meta name="author" content="">
    <link rel="icon" href="Imagens/papagaio.png">

    <title>Entrar</title>

    <!-- Bootstrap core CSS -->
    <link href="bootstrap.min.css" rel="stylesheet">

    <!-- Custom styles for this template -->
    <link href="style.css" rel="stylesheet">
    <link href="stylel.css" rel="stylesheet">
  </head>

  <body>

    <header>
    	<a href="index.html"><img id="logo" src="Imagens/papagaio.png"></a>
    	<input type="busca" name="busca" placeholder=" Buscar"></input>
    	<a href="#busca"><img id="lupa" src="Imagens/lupa.png"></a>
    	<button onclick="window.location.href='login.html'" id="ent" type="button" name="login">Entrar/Cadastrar</button>
    	<a href="perfil.html"><img id="menu" src="Imagens/tt.png"></a>
    </header>

    <main role="main">
      <div class="album py-5 bg-light">
      <div class="container">


        <div id="log">
        	<div id="tit"><p><center>Cadastrar Animal</center></p></div>


          <!-- Area do login -->
          <div id="cadastro">
                <form method="post" action="cadastrandoanimal.php">
                  <table id="encad_table">
                    <tr>
                     <td>Raça do Animal:</td>
                      <td>
                        <input type="text" name="raca" id="usuario" class="campo" maxlength="60" placeholder="Raça " >
                      </td>
                   </tr>
                   <tr>
                     <td>Email:</td>
                      <td>
                        <input type="text" name="email" id="email" class="campo" maxlength="40" placeholder="Email" >
                      </td>   
                   </tr>
                    <tr>
                      <td>Telefone:</td>
                     <td>
                        <input type="text" name="telefone" id="senha" class="campo" maxlength="22" placeholder="Telefone" >
                      </td>
                   </tr>
                   
                   <tr id="btns"></tr>
                   <tr>
                      <td colspan="2">
                       <!-- Botão 1 -->
                       <input type="submit" id="btn_cad" class="area_btn"  value="Cadastrar"/>
                        <!--button type="button" onclick="window.location.href='cadastro.php'" id="btn_cad" Onclick="cad()"  class="area_btn">
                          <div class="efeito_btn"></div><div class="efeito_txt" id="text_cad">Cadastrar</div>
                        </button-->
                     </td>
                   </tr>
                  </table>
                 </form>
               </td>
             </tr>
          </table>
          </div>



        </div>
<!-- Fim do Login -->
      

      </div>
    </div>
  </div>
  </div>

  </main>

  <footer class="text-muted">
    <div class="container">
        <p class="float-right">Juan Felipe da Silva Rangel, 2046385.
      <br>Vinicíus Henrique Soares, 2046458.</p>
      <p>
        <a href="#">Back to top</a>
      </p>
      <p>&copy; Papagaio Adoções, ajude um amiguinho que gosta de ABACATE!</p>
    </div>
  </footer>

</body>
</html>
