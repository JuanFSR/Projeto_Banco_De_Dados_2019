<?php
$host = "localhost";
$user = "root";
$pass = "";
$banco = "cadastro_pessoa";
$conexao = mysqli_connect($host, $user, $pass, $banco) or die (mysqli_error());
mysqli_select_db($conexao,$banco) or die (mysqli_error());


	$email = $_REQUEST['email'];
	$senha = $_REQUEST['senha'];
	$nova_senha= $_REQUEST['nova_senha'];
	$result = mysqli_query($conexao, "SELECT id FROM usuarios WHERE email='$email' and senha='$senha' ") or die(mysqli_error());

	$row = mysqli_fetch_array($result);
		$id = $row['id'];
	if($row > 0){
	$up = mysqli_query($conexao, "UPDATE usuarios SET senha='$nova_senha' WHERE id=$id");
	echo "1";
	}
	else{
		echo "2";
	}
?>
