<!--?php 
$host = "localhost";
$user = "root";
$pass = "";
$banco = "cadastro";
$conexao = mysqli_connect($host, $user, $pass, $banco) or die(mysqli_error());
	if(!$conexao){
		print "Falha na conexão com o Banco de Dados";
	}

$selectDB = mysqli_select_db($conexao, $banco) or die(mysqli_error());

			if(isset($_POST['Cadastrar'])){
$nome=$_POST['nome'];
$sobrenome =$_POST['sobrenome'];
$pais=$_POST['pais'];
$regiao=$_POST['regiao'];
$email=$_POST['email'];
$senha=$_POST['senha'];
$confirmacao_senha=$_POST['confirmacao_senha'];
$sql = mysqli_query($conexao,"INSERT INTO usuarios (nome, sobrenome, pais, regiao, email, senha, confirmacao_senha)
	VALUES('$nome', '$sobrenome', '$pais', '$regiao', '$email', '$senha', '$confirmacao_senha')");

echo"<center><h1>Cadastro efetuado com sucesso!</h1></center>";
mysqli_close($conexao);
}

?-->

<!doctype html>
<html lang="en">
  <head>
    <meta charset="utf-8">
    <meta name="Comprarport" content="width=device-width, initial-scale=1, shrink-to-fit=no">
    <meta name="description" content="">
    <meta name="author" content="">
    <link rel="icon" href="Imagens/papagaio.png">

    <title>Entrar</title>

    <!-- Bootstrap core CSS -->
    <link href="bootstrap.min.css" rel="stylesheet">

    <!-- Custom styles for this template -->
    <link href="style.css" rel="stylesheet">
    <link href="stylel.css" rel="stylesheet">
  </head>

  <body>

    <header>
    	<a href="index.html"><img id="logo" src="Imagens/papagaio.png"></a>
    	<input type="busca" name="busca" placeholder=" Buscar"></input>
    	<a href="#busca"><img id="lupa" src="Imagens/lupa.png"></a>
    	<button onclick="window.location.href='login.html'" id="ent" type="button" name="login">Entrar/Cadastrar</button>
    	<a href="perfil.html"><img id="menu" src="Imagens/tt.png"></a>
    </header>

    <main role="main">
      <div class="album py-5 bg-light">
      <div class="container">


        <div id="log">
        	<div id="tit"><p>Entrar/Cadastrar</p></div>


          <!-- Area do login -->
          <div id="login">
            <table id="encad">
              <tr>
                <td id="divs">
                  <form method="POST" action="">
                    <table id="encad_table">
                     <tr>
                      <td>Email:</td>
                      <td>
                        <input type="text" name="email" value="" id="email" class="campo" maxlength="40" placeholder="Email" >
                      </td>
                      </tr>
                      <tr>
                       <td>Senha:</td>
                       <td>
                         <input type="password" name="senha" id="senha" class="campo" maxlength="22" placeholder="Senha" >
                        </td>
                      </tr>
                      <tr id="btns"></tr>
                      <tr>
                        <td colspan="2">
                          <!-- Botão 1 -->
                         <input type="submit" id="btn_ent" class="area_btn" value="Entrar" />
                            <!----div class="efeito_btn"></div><div class="efeito_txt" id="text_ent">Entrar</div>
                         </button-->
                          <!-- Botao 2 
                         <button type="button" id="btn_eas" Onclick="eas()"  class="area_btn">
                            <div class="efeito_btn"></div><div class="efeito_txt" id="text_eas">Esqueceu a Senha?</div>
                
                        </button-->
                        <input type="submit" id="btn_eas" class="area_btn" value="Esqueceu a Senha?" />
                        </td>
                      </tr>
                    </table>
        
                
<!-- Fim do Cadastro -->
        

        </div>
      </div>
    </div>
    </div>

    </main>

    <footer class="text-muted">
      <div class="container">
      	<p class="float-right">Juan Felipe da Silva Rangel, 2046385.
        <br>Vinicíus Henrique Soares, 2046458.</p>
        <p>
          <a href="#">Back to top</a>
        </p>
        <p>&copy; Papagaio Adoções, ajude um amiguinho que gosta de ABACATE!</p>
      </div>
    </footer>

  </body>
</html>
