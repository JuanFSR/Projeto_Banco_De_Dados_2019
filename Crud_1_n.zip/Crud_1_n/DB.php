<!-- Login  -->
<?php
$host = "localhost";
$user = "root";
$pass = "";
$banco = "cadastro_pessoas";
$conexao = mysqli_connect($host , $user, $pass, $banco) or die(mysqli_error());
mysqli_select_db($conexao , $banco) or die(mysqli_error());

?>

<html>

<head>
<script type="text/javascript">
function loginsuccessfully(){
	setTimeout("window.location='painel.php'", 1000);
}

function loginfailed(){
	setTimeout("window.location='login.php'", 1000);
}

</script>

</head>

<body>
<?php
$email = $_POST['email'];
$senha = $_POST['senha'];
$sql = mysqli_query($conexao,"SELECT * FROM usuarios WHERE email = '$email' AND senha= '$senha'") or die(mysqli_error($conexao));
$row = mysqli_num_rows($sql);
if($row > 0){
	session_start();
	$_SESSION['email']=$_POST['email'];
	$_SESSION['senha']=$_POST['senha'];
	echo"<script>loginsuccessfully()</script>";
//	$nom = mysqli_query($conexao, "SELECT ")
	
}
else{
	echo"<center>Nome de usuário ou senha invalidos</center>";
	echo"<script>loginfailed()</script>";
}

?>
</body>
</html>