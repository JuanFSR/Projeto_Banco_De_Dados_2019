<html>
<head>
	<title>Cadastrando</title>
	<script type="text/javascript">
	function loginsuccessfully(){
		setTimeout("window.location='index.php'", 2000);
	}
	function loginfailed(){
		setTimeout("window.location='login.php'", 2000);	
	}
	</script>
</head>
<body>
<?php
$host = "localhost";
$user = "root";
$pass = "";
$banco = "cadastro_pessoa";
$conexao = mysqli_connect($host, $user, $pass, $banco) or die (mysqli_error());
mysqli_select_db($conexao,$banco) or die (mysqli_error());
?>



<?php
$nome = $_POST['nome'];
$email = $_POST['email'];
$senha = $_POST['senha'];
$confir_senha = $_POST['confir_senha'];
$sql = mysqli_query($conexao,"INSERT INTO usuarios(nome,email,senha, confir_senha) VALUES ('$nome','$email','$senha','$confir_senha')   ");
echo "<center>Cadastro efetuado com sucesso!</center>";
echo "<script>loginsuccessfully()</script>";

?>
</body>
</html>