<?php
$host = "localhost";
$user = "root";
$pass = "";
$banco = "cadastro_pessoa";
$conexao = mysqli_connect($host, $user, $pass, $banco) or die (mysqli_error());
mysqli_select_db($conexao,$banco) or die (mysqli_error());
?>

<html>
<head>
	
</head>
<body>
<?php
	$email = $_POST['email'];
	$senha = $_POST['senha'];
	$nova_senha= $_POST['nova_senha'];
	$confir_nova_senha= $_POST['confir_nova_senha'];
	$result = mysqli_query($conexao, "SELECT id FROM usuarios WHERE email='$email' and senha='$senha' ") or die(mysqli_error());

	$row = mysqli_num_rows($result);
	if($row > 0){
		$up = mysqli_query("UPDATE usuarios SET senha='$nova_senha',  WHERE id=$result");
	}
	else{
		echo "<center>Senha ou email incorretos!</center>";
	}
?>
</body>
</html>