<?php
$host = "localhost";
$user = "root";
$pass = "";
$banco = "cadastro_pessoa";
$conexao = mysqli_connect($host, $user, $pass, $banco) or die (mysqli_error());
mysqli_select_db($conexao,$banco) or die (mysqli_error());
?>

<html>
<head>
	<title>Autenticando usuário</title>
	<script type="text/javascript">
	function loginsuccessfully(){
		setTimeout("window.location='index.php'", 2000);
	}
	function loginfailed(){
		setTimeout("window.location='log.php'", 2000);	
	}
	</script>
</head>
<body>



<?php
$email = $_POST['email'];
$senha = $_POST['senha'];
$sql = mysqli_query($conexao, "SELECT * FROM usuarios WHERE email='$email' and senha='$senha' ") or die(mysqli_error());
$row = mysqli_num_rows($sql);
if($row > 0) {
	session_start();
	$_SESSION['email']= $_POST['email'];
	$_SESSION['senha']= $_POST['senha'];
	echo "<center>Login feito com sucesso!</center>";
	echo "<script>loginsuccessfully()</script>";

}else{
	echo "<center>Nome de usuário ou senha inválidos!</center>";
	echo "<script>loginfailed()</script>";
}

?>

</body>
</html>
